package BE.Odisee.Oxyplast.Domain;

/**
 * @author Lesuisse
 * @version 1.0
 * @created 24-Feb-2016 13:44:35
 */
public class Accountverantwoordelijke extends Werknemer {

	private String Achternaam;
	private String Email;
	private int Telefoonnummer;
	private String Voornaam;

	public Accountverantwoordelijke(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}