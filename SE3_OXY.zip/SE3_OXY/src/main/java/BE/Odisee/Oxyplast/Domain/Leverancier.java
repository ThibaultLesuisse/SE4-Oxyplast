package BE.Odisee.Oxyplast.Domain;

/**
 * @author Lesuisse
 * @version 1.0
 * @created 24-Feb-2016 13:44:06
 */
public class Leverancier {

	private int LeverancierID;
	private String Naam;

	public Leverancier(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * 
	 * @param Naam
	 */
	public int LeverancierID(String Naam){
		return 0;
	}

}