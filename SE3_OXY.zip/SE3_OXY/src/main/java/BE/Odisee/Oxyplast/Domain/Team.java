package BE.Odisee.Oxyplast.Domain;
import java.lang.reflect.Array;

/**
 * @author Lesuisse
 * @version 1.0
 * @created 24-Feb-2016 13:43:51
 */
public class Team {

	private int TeamID;
	private Array Werknemers;
	public Werknemer m_Werknemer;

	public Team(){

	}

	public void finalize() throws Throwable {

	}

	public int getTeamId(){
		return 0;
	}

	/**
	 * 
	 * @param werknemerId
	 */
	public void verwijderWerknemer(int werknemerId){
		
	}

	/**
	 * 
	 * @param werknemerID
	 */
	public void voegWerknemerToe(int werknemerID){
		
	}

}