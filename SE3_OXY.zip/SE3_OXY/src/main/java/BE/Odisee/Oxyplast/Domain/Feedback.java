package BE.Odisee.Oxyplast.Domain;

/**
 * @author Lesuisse
 * @version 1.0
 * @created 24-Feb-2016 13:42:37
 */
public class Feedback {

	private String Feedback;
	private int FeedbackID;
	private int KlantID;
	private int PrototypeID;

	public Feedback(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * 
	 * @param Feedback
	 * @param KlantID
	 * @param PrototypeID
	 */
	public int FeedbackID(String Feedback, int KlantID, int PrototypeID){
		return 0;
	}

}