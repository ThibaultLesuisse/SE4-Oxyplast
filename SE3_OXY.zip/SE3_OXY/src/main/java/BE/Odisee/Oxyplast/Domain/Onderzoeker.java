package BE.Odisee.Oxyplast.Domain;

/**
 * @author Lesuisse
 * @version 1.0
 * @created 24-Feb-2016 13:44:21
 */
public class Onderzoeker extends Werknemer {

	private String Achternaam;
	private String Email;
	private int TelefoonNummer;
	private String Voornaam;

	public Onderzoeker(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}