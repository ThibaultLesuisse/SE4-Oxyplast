package BE.Odisee.Oxyplast.Domain;

/**
 * @author Lesuisse
 * @version 1.0
 * @created 24-Feb-2016 13:42:14
 */
public class Opbrengst {

	private double OpbrengenstenHoeveelheid;
	public Project m_Project;

	public Opbrengst(){

	}

	public void finalize() throws Throwable {

	}

	public double BerekenOpbrengst(){
		return 0;
	}

}