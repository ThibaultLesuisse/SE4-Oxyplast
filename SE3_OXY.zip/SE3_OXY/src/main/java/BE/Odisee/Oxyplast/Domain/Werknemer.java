package BE.Odisee.Oxyplast.Domain;

/**
 * @author Lesuisse
 * @version 1.0
 * @created 24-Feb-2016 13:44:14
 */
public class Werknemer {

	private int BadgeNummer;
	private int WerknemerID;

	public Werknemer(){

	}

	public void finalize() throws Throwable {

	}

	public void Degradeer(){

	}

	public void Ontsla(){

	}

	public void Promoveer(){

	}

	public void Schors(){

	}

	public void VerwijderVangeschorst(){

	}

}